﻿using _450MIST.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // add services to the container; dependency injection
        builder.Services.AddControllersWithViews();

        //fetch connection string information and store in a variable
        var connectionString = builder.Configuration.GetConnectionString("BooksDbConnection");

        //add the DbContext class to the services using sqlserver as the default DBMS along with the connection string fetched in the previous statement

        builder.Services.AddDbContext<BooksDBContext>(options => options.UseSqlServer(connectionString));

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (!app.Environment.IsDevelopment())
        {
            app.UseExceptionHandler("/Home/Error");
            // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
            app.UseHsts();
        }

        app.UseHttpsRedirection();
        app.UseStaticFiles();

        app.UseRouting();

        app.UseAuthorization();

        //default routing pattern
        // /book/index/id
        app.MapControllerRoute(
            name: "default",
            pattern: "{controller=Book}/{action=Index}/{id?}");

        app.Run();
    }
}